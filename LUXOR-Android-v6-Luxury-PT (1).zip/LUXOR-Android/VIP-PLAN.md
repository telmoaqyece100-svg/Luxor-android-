# LUXOR VIP — proposta de plano

- Preço proposto: US$100
- Duração: 2 meses (60 dias, a confirmar nos termos)
- Benefícios propostos: acesso a campanhas VIP quando disponíveis, suporte prioritário e histórico/resumo de atividade avançados.

## Salvaguardas essenciais
- VIP não promete nem garante rendimento, aprovação de inquéritos ou recuperação do preço pago.
- Não exigir VIP para levantar recompensas já ganhas.
- Não vender acesso a inquéritos inexistentes; indicar disponibilidade, critérios de elegibilidade e limites antes da compra.
- Mostrar preço total, duração, data de início/fim, renovação automática (se existir), cancelamento e reembolso antes do pagamento.
- Não usar linguagem que sugira retorno garantido do investimento.
- Implementar cobrança somente depois de rever legislação de consumo/serviços digitais, fiscalidade e políticas da Google Play para o país de distribuição.
- Guardar comprovativos e estados da subscrição no backend; nunca confiar num estado VIP definido apenas no dispositivo.

## Estado atual
O ecrã VIP é uma demonstração visual. O botão regista apenas interesse local e não cobra, ativa nem renova qualquer plano.
