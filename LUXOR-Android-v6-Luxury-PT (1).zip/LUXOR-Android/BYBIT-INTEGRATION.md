# LUXOR — Plano seguro de integração Bybit

## Estado atual
A aplicação Android continua a ser um protótipo local. Não existe ligação à Bybit, não são guardadas chaves API e nenhum levantamento pode ser executado.

## Decisão para a conta pessoal
Não ligar uma conta pessoal como carteira coletiva de clientes nem receber nela fundos de terceiros sem confirmação escrita da Bybit de que o modelo de negócio e a utilização da API são permitidos para essa conta e jurisdição. Confirmar também com assessoria jurídica/regulatória em Angola e nos mercados onde a LUXOR operar se a atividade exige licença, parceiro autorizado ou estrutura empresarial.

## Arquitetura obrigatória
1. Android envia um pedido autenticado ao backend LUXOR.
2. Backend valida utilizador, KYC aplicável, elegibilidade e estado da recompensa.
3. Um livro-razão no servidor regista cada crédito/débito com identificador único e trilho de auditoria.
4. Um operador autoriza o pagamento; regras de risco e limites bloqueiam pedidos suspeitos.
5. Serviço de pagamentos no servidor comunica com a API oficial Bybit, se aprovado pela Bybit.
6. Backend reconcilia o estado da transferência antes de marcar o levantamento como concluído.
7. A app apenas mostra o estado recebido do backend. Nunca assina chamadas Bybit nem contém segredos.

## Requisitos de API a confirmar
- A documentação Bybit V5 descreve o endpoint de levantamento `POST /v5/asset/withdraw/create`.
- A documentação indica que o endereço deve estar na lista de endereços autorizados e que o endpoint de levantamento deve ser chamado com a API key da conta principal (master UID).
- A permissão `Wallet -> Withdraw` é uma permissão sensível. Não a conceder a uma chave usada para funções que não necessitam dela.
- A documentação de autenticação recomenda tratar API key e secret como palavras-passe. Guardar segredos apenas num gestor de segredos do backend, com IP fixo autorizado, rotação, logs sem segredos e acesso mínimo.
- Confirmar no endpoint oficial de moedas/cadeias que USDT e a rede TRC20 (frequentemente identificada como TRX) estão disponíveis para a conta, país e momento da operação; não assumir disponibilidade.
- Confirmar taxas, montantes mínimos, limites, Travel Rule/KYC e restrições da conta diretamente com a Bybit.

## Sequência de implementação recomendada
### Fase A — sem dinheiro real
- Criar backend de teste e autenticação.
- Simular o livro-razão com saldo de teste separado de qualquer saldo real.
- Criar pedidos de levantamento com estado `PENDING_REVIEW`.
- Implementar aprovação manual, idempotência, limites e auditoria.
- Testar em ambiente de teste quando a funcionalidade estiver disponível.

### Fase B — produção, apenas após aprovação
- Obter autorização/estrutura empresarial adequada.
- Confirmar a elegibilidade da conta e do modelo com Bybit.
- Configurar uma API key nova, com permissões mínimas e IP allowlist do servidor.
- Nunca partilhar a API secret, seed phrase, códigos 2FA ou palavra-passe com terceiros.
- Fazer primeiro um teste de baixo valor, após revisão técnica, legal e operacional.

## Nunca fazer
- Nunca colocar API key/secret no APK, Git, ficheiros de configuração públicos ou mensagens.
- Nunca pedir ao utilizador a palavra-passe ou códigos 2FA da Bybit.
- Nunca creditar US$10 apenas porque a app enviou uma resposta: o patrocinador tem de financiar e o servidor tem de aprovar a resposta.
- Nunca mostrar um levantamento como pago antes de confirmação verificável da Bybit.

## Referências oficiais
- Bybit V5 Withdraw: https://bybit-exchange.github.io/docs/v5/asset/withdraw
- Bybit V5 API key information: https://bybit-exchange.github.io/docs/v5/user/apikey-info
- Bybit API integration guidance: https://bybit-exchange.github.io/docs/v5/guide
