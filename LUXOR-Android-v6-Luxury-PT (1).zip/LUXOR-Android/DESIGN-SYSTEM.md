# LUXOR — sistema visual

- Nome: LUXOR
- Direção: luxo premium
- Símbolo: coroa
- Idioma inicial: português
- Preto profundo: `#0C0C0E`
- Grafite: `#17171B`
- Dourado: `#D7B56D`
- Dourado claro: `#F0D99F`
- Marfim: `#F7F3E9`
- Texto secundário: `#A6A19A`

## Princípios de interface
1. Contraste elevado e hierarquia tipográfica simples.
2. Dourado reservado a ações e informação de destaque.
3. Cartões arredondados e espaçamento consistente.
4. Português europeu simples e claro.
5. Saldos, campanhas e pagamentos de demonstração sempre identificados como tal.
