package com.luxor.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.Poll
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material.icons.filled.Wallet
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Night = Color(0xFF0C0C0E)
private val Panel = Color(0xFF17171B)
private val PanelLight = Color(0xFF202025)
private val Gold = Color(0xFFD7B56D)
private val GoldLight = Color(0xFFF0D99F)
private val Ivory = Color(0xFFF7F3E9)
private val Muted = Color(0xFFA6A19A)
private val WarningBg = Color(0xFF342B1B)

private data class Survey(val id: Int, val title: String, val description: String, val minutes: Int)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LuxorApp() }
    }
}

@Composable
private fun LuxorApp() {
    var tab by remember { mutableStateOf("Inquéritos") }
    var vipInterest by remember { mutableStateOf(false) }
    var selectedSurvey by remember { mutableStateOf<Survey?>(null) }
    var notice by remember { mutableStateOf("Esta é uma versão de demonstração. Não existem pagamentos ativos.") }
    var submitted by remember { mutableStateOf(setOf<Int>()) }

    val surveys = listOf(
        Survey(1, "Hábitos de compra online", "Partilhe a sua experiência com compras e entregas.", 8),
        Survey(2, "Experiência digital", "Ajude a avaliar aplicações e serviços digitais.", 6),
        Survey(3, "Preferências de consumo", "Conte-nos o que valoriza nos produtos do dia a dia.", 10)
    )
    val tabs = listOf("Inquéritos", "Carteira", "VIP", "Patrocínios", "Conta")

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Gold,
            onPrimary = Night,
            secondary = GoldLight,
            background = Night,
            surface = Panel,
            onSurface = Ivory,
            onBackground = Ivory
        )
    ) {
        Scaffold(
            containerColor = Night,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Ivory) {
                    tabs.forEach { item ->
                        val selected = tab == item && selectedSurvey == null
                        NavigationBarItem(
                            selected = selected,
                            onClick = { tab = item; selectedSurvey = null },
                            icon = {
                                val tint = if (selected) Gold else Muted
                                when (item) {
                                    "Inquéritos" -> Icon(Icons.Default.Poll, null, tint = tint)
                                    "Carteira" -> Icon(Icons.Default.Wallet, null, tint = tint)
                                    "VIP" -> Icon(Icons.Default.Stars, null, tint = tint)
                                    "Patrocínios" -> Icon(Icons.Default.Campaign, null, tint = tint)
                                    else -> Icon(Icons.Default.AccountCircle, null, tint = tint)
                                }
                            },
                            label = {
                                Text(item, color = if (selected) Gold else Muted, fontSize = 10.sp, maxLines = 1)
                            },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = Color(0xFF30291D),
                                selectedIconColor = Gold,
                                unselectedIconColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).background(Night)
            ) {
                LuxorTopBar()
                if (selectedSurvey != null) {
                    SurveyDetail(
                        survey = selectedSurvey!!,
                        alreadySubmitted = submitted.contains(selectedSurvey!!.id),
                        onBack = { selectedSurvey = null },
                        onSubmit = {
                            submitted = submitted + selectedSurvey!!.id
                            notice = "Resposta guardada apenas nesta demonstração. Não foi creditada qualquer recompensa."
                            selectedSurvey = null
                            tab = "Inquéritos"
                        }
                    )
                } else {
                    when (tab) {
                        "Inquéritos" -> SurveyScreen(surveys, submitted) { selectedSurvey = it }
                        "Carteira" -> WalletScreen(submitted.size, notice)
                        "VIP" -> VipScreen(vipInterest) { vipInterest = true }
                        "Patrocínios" -> FundingScreen()
                        else -> AccountScreen(notice)
                    }
                }
            }
        }
    }
}

@Composable
private fun LuxorTopBar() {
    Row(
        Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(42.dp).clip(RoundedCornerShape(13.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF3A3020), Color(0xFF17130D))))
                .border(1.dp, Color(0xFF78623A), RoundedCornerShape(13.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text("♛", color = GoldLight, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(11.dp))
        Column(verticalArrangement = Arrangement.spacedBy((-3).dp)) {
            Text("LUXOR", color = Ivory, fontSize = 22.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
            Text("A TUA OPINIÃO TEM VALOR", color = Gold, fontSize = 8.sp, letterSpacing = 1.25.sp)
        }
        Spacer(Modifier.weight(1f))
        Box(
            Modifier.size(38.dp).clip(CircleShape).background(Panel),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Default.NotificationsNone, "Notificações", tint = GoldLight) }
    }
}

@Composable
private fun ScreenColumn(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(horizontal = 20.dp),
        content = content
    )
}

@Composable
private fun Eyebrow(text: String) {
    Text(text.uppercase(), color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
}

@Composable
private fun DemoBanner(text: String) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(WarningBg).padding(12.dp),
        verticalAlignment = Alignment.Top
    ) {
        Icon(Icons.Default.Lock, null, tint = GoldLight, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(9.dp))
        Text(text, color = Color(0xFFE8D8B6), fontSize = 11.sp, lineHeight = 16.sp)
    }
}

@Composable
private fun SurveyScreen(surveys: List<Survey>, submitted: Set<Int>, onOpen: (Survey) -> Unit) {
    ScreenColumn {
        Eyebrow("Bem-vindo à LUXOR")
        Spacer(Modifier.height(6.dp))
        Text("A sua opinião\nvale mais.", color = Ivory, fontSize = 29.sp, lineHeight = 34.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Participe em estudos de mercado e partilhe o que pensa.", color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
        Spacer(Modifier.height(18.dp))
        Card(
            colors = CardDefaults.cardColors(containerColor = Panel),
            shape = RoundedCornerShape(20.dp)
        ) {
            Row(Modifier.fillMaxWidth().padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Eyebrow("Recompensa anunciada")
                    Spacer(Modifier.height(5.dp))
                    Text("US$ 1", color = GoldLight, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                    Text("por inquérito aprovado", color = Muted, fontSize = 11.sp)
                }
                Box(
                    Modifier.size(54.dp).clip(CircleShape).background(Color(0xFF30291D)),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.EmojiEvents, null, tint = Gold, modifier = Modifier.size(28.dp)) }
            }
        }
        Spacer(Modifier.height(14.dp))
        DemoBanner("DEMONSTRAÇÃO: os inquéritos apresentados são exemplos. As recompensas só poderão ser pagas quando houver campanhas financiadas, validação no servidor e pagamentos operacionais.")
        Spacer(Modifier.height(20.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Inquéritos disponíveis", color = Ivory, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text("EXEMPLOS", color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
        }
        Spacer(Modifier.height(10.dp))
        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(bottom = 18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(surveys) { survey ->
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { onOpen(survey) },
                    colors = CardDefaults.cardColors(containerColor = Panel),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF30291D)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Assessment, null, tint = Gold)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(survey.title, color = Ivory, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Spacer(Modifier.height(4.dp))
                            Text("${survey.minutes} min · exemplo demonstrativo", color = Muted, fontSize = 10.sp)
                        }
                        Icon(Icons.Default.ChevronRight, null, tint = Gold)
                    }
                }
            }
        }
    }
}

@Composable
private fun SurveyDetail(survey: Survey, alreadySubmitted: Boolean, onBack: () -> Unit, onSubmit: () -> Unit) {
    var answer by remember(survey.id) { mutableStateOf("") }
    ScreenColumn {
        TextButton(onClick = onBack, contentPadding = PaddingValues(0.dp)) {
            Icon(Icons.Default.ArrowBack, null, tint = Gold)
            Spacer(Modifier.width(6.dp))
            Text("Voltar aos inquéritos", color = Gold)
        }
        Spacer(Modifier.height(12.dp))
        Eyebrow("Inquérito de demonstração")
        Spacer(Modifier.height(6.dp))
        Text(survey.title, color = Ivory, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(survey.description, color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(24.dp))
        Text("Com que frequência faz compras online?", color = Ivory, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(12.dp))
        listOf("Todas as semanas", "Uma vez por mês", "Raramente", "Nunca").forEach { option ->
            Card(
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable(enabled = !alreadySubmitted) { answer = option },
                colors = CardDefaults.cardColors(containerColor = if (answer == option) Color(0xFF30291D) else Panel),
                shape = RoundedCornerShape(13.dp)
            ) {
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = answer == option, onClick = { answer = option }, enabled = !alreadySubmitted, colors = RadioButtonDefaults.colors(selectedColor = Gold, unselectedColor = Muted))
                    Text(option, color = Ivory, fontSize = 13.sp)
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        DemoBanner("Esta pergunta é ilustrativa. Enviar a resposta não gera saldo nem pagamento.")
        Spacer(Modifier.height(18.dp))
        Button(
            onClick = onSubmit,
            enabled = answer.isNotBlank() && !alreadySubmitted,
            modifier = Modifier.fillMaxWidth().height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Night, disabledContainerColor = PanelLight, disabledContentColor = Muted),
            shape = RoundedCornerShape(14.dp)
        ) { Text(if (alreadySubmitted) "Resposta já enviada" else "Enviar resposta", fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun WalletScreen(submittedCount: Int, notice: String) {
    ScreenColumn {
        Eyebrow("Área financeira")
        Spacer(Modifier.height(6.dp))
        Text("A sua carteira", color = Ivory, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        Card(
            colors = CardDefaults.cardColors(containerColor = Panel),
            shape = RoundedCornerShape(22.dp)
        ) {
            Column(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF272116), Panel))).padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Eyebrow("Saldo disponível")
                    Spacer(Modifier.weight(1f))
                    Icon(Icons.Default.Wallet, null, tint = Gold)
                }
                Spacer(Modifier.height(8.dp))
                Text("US$ 0,00", color = Ivory, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                Text("Saldo demonstrativo · não levantável", color = Muted, fontSize = 11.sp)
                Spacer(Modifier.height(18.dp))
                HorizontalDivider(color = Color(0xFF49402E))
                Spacer(Modifier.height(12.dp))
                Text("$submittedCount resposta(s) de exemplo submetidas", color = GoldLight, fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(20.dp))
        Text("Levantamentos", color = Ivory, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Método previsto: USDT na rede TRC20. A integração com a Bybit ainda não está ativa.", color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
        Spacer(Modifier.height(14.dp))
        OutlinedButton(onClick = {}, enabled = false, modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(13.dp)) {
            Text("Levantamentos indisponíveis nesta versão")
        }
        Spacer(Modifier.height(18.dp))
        DemoBanner("A carteira ainda não está ligada a um servidor nem a um prestador de pagamentos. Não deposite fundos nesta versão.")
        Spacer(Modifier.height(12.dp))
        Text(notice, color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun VipScreen(requested: Boolean, onRequest: () -> Unit) {
    ScreenColumn {
        Eyebrow("Experiência exclusiva")
        Spacer(Modifier.height(6.dp))
        Text("LUXOR VIP", color = Ivory, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("Uma experiência premium", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(18.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF352A18), Panel))).padding(21.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("♛", color = GoldLight, fontSize = 30.sp)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("MEMBRO LUXOR", color = GoldLight, fontSize = 10.sp, letterSpacing = 1.6.sp, fontWeight = FontWeight.Bold)
                        Text("VIP", color = Ivory, fontSize = 22.sp, fontWeight = FontWeight.Black)
                    }
                }
                Spacer(Modifier.height(18.dp))
                Text("US$ 100", color = Ivory, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                Text("por 2 meses · preço proposto", color = Muted, fontSize = 11.sp)
                Spacer(Modifier.height(18.dp))
                Text("BENEFÍCIOS PROPOSTOS", color = Gold, fontSize = 10.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(9.dp))
                listOf("Acesso a campanhas VIP quando disponíveis", "Suporte prioritário", "Resumo avançado da atividade").forEach {
                    Row(Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Stars, null, tint = Gold, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(it, color = Ivory, fontSize = 12.sp)
                    }
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        DemoBanner("O VIP não garante inquéritos, aprovação, rendimentos ou retorno do preço. Não será cobrado nem ativado nesta demonstração. A renovação automática só poderá ocorrer com consentimento explícito.")
        Spacer(Modifier.height(16.dp))
        if (requested) Text("O seu interesse foi registado apenas nesta demonstração. Não houve cobrança nem ativação.", color = GoldLight, fontSize = 12.sp)
        Button(
            onClick = onRequest,
            enabled = !requested,
            modifier = Modifier.fillMaxWidth().height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Night, disabledContainerColor = PanelLight, disabledContentColor = Muted),
            shape = RoundedCornerShape(14.dp)
        ) { Text(if (requested) "Interesse registado" else "Tenho interesse no VIP", fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(12.dp))
        Text("Antes de qualquer cobrança serão necessários termos completos, cancelamento simples, política de reembolso e validação legal e das regras da Google Play.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
    }
}

@Composable
private fun FundingScreen() {
    ScreenColumn {
        Eyebrow("Parcerias e campanhas")
        Spacer(Modifier.height(6.dp))
        Text("Financiamento", color = Ivory, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Text("A LUXOR procura parceiros para apoiar estudos de mercado.", color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
        Spacer(Modifier.height(18.dp))
        DemoBanner("Painel de demonstração. Não existem patrocínios nem fundos confirmados nesta versão.")
        Spacer(Modifier.height(16.dp))
        FundingCard("Patrocinadores", "Financiamento de campanhas por empresas", "US$ 0,00", Icons.Default.Campaign)
        Spacer(Modifier.height(10.dp))
        FundingCard("Capital próprio", "Investimento do projeto", "US$ 0,00", Icons.Default.Wallet)
        Spacer(Modifier.height(10.dp))
        FundingCard("Reserva para recompensas", "Fundos confirmados e reservados", "US$ 0,00", Icons.Default.Lock)
        Spacer(Modifier.height(18.dp))
        Text("Objetivo do primeiro piloto", color = Ivory, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text("US$ 1.000 para financiar até 1.000 respostas aprovadas a US$ 1 cada. Custos operacionais e taxas são calculados separadamente.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
        Spacer(Modifier.height(12.dp))
        Text("Cada campanha só deverá ser publicada depois de o orçamento estar recebido e reservado. A aprovação das respostas será feita no servidor.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
    }
}

@Composable
private fun FundingCard(title: String, detail: String, amount: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(15.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF30291D)), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = Gold)
            }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Ivory, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                Spacer(Modifier.height(3.dp))
                Text(detail, color = Muted, fontSize = 10.sp)
            }
            Text(amount, color = GoldLight, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
    }
}

@Composable
private fun AccountScreen(notice: String) {
    ScreenColumn {
        Eyebrow("Perfil e segurança")
        Spacer(Modifier.height(6.dp))
        Text("A sua conta", color = Ivory, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(17.dp)) {
            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AccountCircle, null, tint = Gold, modifier = Modifier.size(35.dp))
                    Spacer(Modifier.width(11.dp))
                    Column {
                        Text("Bem-vindo à LUXOR", color = Ivory, fontWeight = FontWeight.Bold)
                        Text("Perfil de demonstração", color = Muted, fontSize = 11.sp)
                    }
                }
                Spacer(Modifier.height(14.dp))
                HorizontalDivider(color = PanelLight)
                Spacer(Modifier.height(12.dp))
                Text("Idioma", color = Muted, fontSize = 11.sp)
                Text("Português", color = Ivory, fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                Text("Estado da aplicação", color = Muted, fontSize = 11.sp)
                Text("Protótipo local · serviços reais ainda não ligados", color = GoldLight, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(14.dp))
        Text("Privacidade e apoio", color = Ivory, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(7.dp))
        Text("Antes do lançamento serão adicionados política de privacidade, termos de utilização, contacto de suporte e ferramentas para gerir ou eliminar a conta.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
        Spacer(Modifier.height(14.dp))
        DemoBanner(notice)
    }
}
