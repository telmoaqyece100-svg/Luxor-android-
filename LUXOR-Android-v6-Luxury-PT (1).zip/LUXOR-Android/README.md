# LUXOR Android — protótipo visual premium

Aplicação Android nativa em Kotlin + Jetpack Compose, com identidade visual escolhida: luxo premium, preto e dourado, em português, com símbolo de coroa.

## Identidade visual
- Fundo preto profundo e cartões grafite.
- Dourado como cor de destaque.
- Marca LUXOR com emblema de coroa.
- Interface integralmente em português.

## Ecrãs incluídos
- Inquéritos de exemplo, com recompensa prevista de US$1 por resposta aprovada.
- Detalhe e submissão local de uma resposta demonstrativa.
- Carteira com saldo demonstrativo US$0,00 e levantamentos desativados.
- Plano VIP proposto de US$100 por dois meses, sem cobrança ou ativação.
- Painel de patrocínios com valores demonstrativos e objetivo de piloto de US$1.000.
- Conta e estado da aplicação.

## Abrir e executar
1. Instale o Android Studio.
2. Abra esta pasta no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Execute num emulador ou dispositivo Android (API 24+).

## Limites importantes
Este projeto continua a ser um protótipo de interface. Não inclui backend, autenticação real, base de dados, campanhas financiadas, validação de respostas no servidor, carteira real, processamento de pagamentos ou integração ativa com a Bybit. Os exemplos não representam oportunidades remuneradas reais.

Antes de lançar será necessário desenvolver e testar os serviços de backend, segurança, gestão de consentimentos, privacidade, suporte, moderação, prevenção de fraude e integrações de pagamento autorizadas. Nunca colocar chaves API, palavras-passe, frases-semente ou códigos de autenticação no APK.

A recompensa de US$1 só poderá ser creditada após aprovação verificável da resposta e confirmação de fundos reais reservados. O VIP não garante rendimentos e não pode condicionar levantamentos de recompensas já ganhas.
