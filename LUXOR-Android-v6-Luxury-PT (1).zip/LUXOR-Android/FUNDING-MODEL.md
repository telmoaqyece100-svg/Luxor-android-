# LUXOR — Modelo misto de financiamento

## Fontes
1. **Patrocinadores:** empresas contratam campanhas de pesquisa e depositam/pagam o orçamento acordado.
2. **Capital próprio:** fundos da própria LUXOR alocados formalmente para recompensas e custos.

## Regras financeiras obrigatórias
- Manter contas contabilísticas separadas por fonte.
- Só considerar fundos liquidados e disponíveis; não contar promessas, faturas não pagas ou transferências pendentes.
- Reservar o orçamento das recompensas antes de publicar cada campanha.
- Recompensa unitária anunciada: US$10 por resposta elegível e aprovada.
- Para N respostas aprovadas previstas, reservar pelo menos N × US$10, mais taxas e margem operacional.
- Não usar o saldo de um utilizador para financiar outro.
- Livro-razão no servidor, append-only, com IDs únicos, reconciliação e trilho de auditoria.
- Aprovação de respostas separada da autorização do pagamento.
- Política de reembolso e cancelamento das campanhas definida no contrato com o patrocinador.
- Nunca publicar campanhas sem orçamento confirmado.

## Fórmula de controlo
Fundos livres = fundos liquidados de patrocinadores + capital próprio alocado - recompensas reservadas - pagamentos pendentes - despesas/taxas já comprometidas.

A app não deve inferir saldo a partir de valores introduzidos pelo utilizador. O backend e os extratos do prestador financeiro são a fonte de verdade.

## Exemplo
100 recompensas aprovadas × US$10 = US$1.000 de obrigações de recompensa. O orçamento necessário será superior a US$1.000 quando forem incluídas taxas, impostos, custos de operação e eventuais estornos.

## Estado desta versão
O ecrã Financiamento é apenas visual e mostra US$0.00. Não recebe depósitos nem regista capital real. O próximo passo técnico é criar backend e processos contabilísticos, seguido de revisão jurídica e aprovação de parceiros financeiros.
